This is the game crappy bird made by Kári Mímisson.
The game is my version of the classical game flappy bird.
The game is uses Phaser which is a HTML5 game framwork.
To build please run nmp install and run python -m SimpleHTTPServer.
This will start the game on localhost port 8080.

-Kári Mímisson
